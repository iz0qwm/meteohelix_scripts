<?php

	############################################################################
	# 	
	#	Meteotemplate
	# 	http://www.meteotemplate.com
	# 	Free website template for weather enthusiasts
	# 	Author: Jachym
	#           Brno, Czech Republic
	# 	First release: 2015
	#
	############################################################################
	#
	#	Plugin for Meteohelix IoT Pro Weather station by Raffaello Di Martino 
	#
	############################################################################
	#	Version and change log
	#
	# 	v1.0 - Sep 03, 2019
	# 		- initial release	
	#   v1.1 - Feb 03, 2020
	#		- accumulated rain
	#   v1.2 - Feb 04, 2020
	#   	- temperature daily max and min
	#   v2.0 - Feb 04, 2020
	#		- simple UV calculation	
	############################################################################
	

	define('__ROOT__', dirname(dirname(__FILE__)));
	
    // load settings
	if(!file_exists("../settings.php")){
		die("The settings file does not exist! Please go to your control panel and set up the netAtmo plugin.");
	}
	include("../settings.php");;

    $base = "../../../";
    
    // load main info
    require($base."config.php");

    // load dependencies
    require($base."scripts/functions.php");
    
    // check acces authorization
	//$password = $_GET['pass'];
    
    // check if password is correct
    //if($password!=$updatePassword){
    //    if($password==$adminPassword){ // if admin password provided accept, but notify
    //        echo "Authorized via admin password";
    //    }
    //    else{
    //        die("Unauthorized");
    //    }
    //}
	
	########### GET DATA ############
	
	# Settings: General
	$forward_data = 1;
	$json_data_log = 1;
	
	$json_data_logdir = $baseURL . "/plugins/meteohelix/";
	
	$txt_data_logdir = $baseURL . "/plugins/meteohelix/";
	$date_txt = date('Y-m-d');
	
	# Convert HTTP POST variables to json
	#$weather_data = $_POST;
	$weather_data = json_decode(file_get_contents('php://input'), true);
	$weather_data_forward = $_GET;
	
	# Conversion factors
	$f_mph_kmh = 1.60934;
	$f_mph_kts = 0.868976;
	$f_mph_ms = 0.44704;
	$f_in_hpa = 33.86;
	$f_in_mm = 25.4;
	$pa_in_hpa = 0.01;
	$mm_in_f = 0.03937008;

	# Reading accumulated rain file
	$read_acc_rain = "./accumulated_rain.txt";
	if (!file_exists($read_acc_rain)) {	
		$result_acc_rain = 0;
	} else { 
		$file = fopen($read_acc_rain, 'r');
		#while (!feof($file)){ 
			$result_acc_rain = fgets($file);
			#$result_acc_rain = round((double)$result_acc_rain, 2);
			$result_acc_rain = round($result_acc_rain, 2);
		#}
		fclose($file);
	}	
	# Convert data
    # Temps
    @$weather_data['tempc'] = round( $weather_data['temperature'] - 273.15, 2 );
    @$weather_data['dewptc'] = round( $weather_data['dewPoint'] - 273.15, 2 );
    @$weather_data['temperaturec_max'] = round( $weather_data['temperature_max'] - 273.15, 2 );
	@$weather_data['temperaturec_min'] = round( $weather_data['temperature_min'] - 273.15, 2 );
    # Distances
	@$weather_data['dailyrainmm'] = round($weather_data['rain'] + $result_acc_rain, 2);
	#@$weather_data['dailyrainin'] = $weather_data['dailyrainmm'] * $mm_in_f ;	
    #@$weather_data['rainmm'] = round( $weather_data['rainin'] * $f_in_mm, 2 );
    #@$weather_data['dailyrainmm'] = round( $weather_data['dailyrainin'] * $f_in_mm, 2 );
    #@$weather_data['weeklyrainmm'] = round( $weather_data['weeklyrainin'] * $f_in_mm, 2 );
    #@$weather_data['monthlyrainmm'] = round( $weather_data['monthlyrainin'] * $f_in_mm, 2 );
    #@$weather_data['yearlyrainmm'] = round( $weather_data['yearlyrainin'] * $f_in_mm, 2 );
    #@$weather_data['rainratemm'] = round( $weather_data['rainratein'] * $f_in_mm, 2 );
    
    # Baros
    @$weather_data['baromabshpa'] = round( $weather_data['pressure'] * $pa_in_hpa, 2 );
    #@$weather_data['baromrelhpa'] = round( $weather_data['baromrelin'] * $f_in_hpa, 2 );
    
	# UV simple calculation
	if ( $weather_data['irradiation'] < 70 ) 
	{
		$weather_data['uv'] = 0;
	} elseif ( $weather_data['irradiation'] >= 70 && $weather_data['irradiation'] < 440 ) {
		$weather_data['uv'] = 1;
		if ( $weather_data['tempc'] > 28 ) {
			$weather_data['uv'] = 2;
		}
	} elseif ( $weather_data['irradiation'] >= 440 && $weather_data['irradiation'] < 600 ) {
		$weather_data['uv'] = 2;
		if ( $weather_data['tempc'] > 28 ) {
			$weather_data['uv'] = 3;
		}
	} elseif ( $weather_data['irradiation'] >= 600 && $weather_data['irradiation'] < 800 ) {
		$weather_data['uv'] = 3;
		if ( $weather_data['tempc'] > 28 ) {
			$weather_data['uv'] = 4;
		}
	} elseif ( $weather_data['irradiation'] >= 800 && $weather_data['irradiation'] < 1000 ) {	
		$weather_data['uv'] = 4;
		if ( $weather_data['tempc'] > 30 ) {
			$weather_data['uv'] = 6;
		} elseif ( $weather_data['tempc'] > 28 ) {
			$weather_data['uv'] = 4;
		}	
	} elseif ( $weather_data['irradiation'] >= 1000 ) {	
		$weather_data['uv'] = 5;
		if ( $weather_data['tempc'] > 30 ) {
			$weather_data['uv'] = 7;
		} elseif ( $weather_data['tempc'] > 28 ) {
			$weather_data['uv'] = 6;
		}
	}	
	
    # Date and time
    $weather_data['dateutc'] = gmdate("Y-m-d\TH:i:s\Z");
	
	# Forward data to meteotemplate server
	if ( $forward_data == 1 ) 
	{
		@$weather_data_forward['U'] = strtotime( $weather_data['dateutc'] );
		@$weather_data_forward['PASS'] = $forward_server_password ;
		@$weather_data_forward['T'] = $weather_data['tempc'] ;
		@$weather_data_forward['H'] = $weather_data['humidity'] ;
		@$weather_data_forward['P'] = $weather_data['baromabshpa'] ;
		@$weather_data_forward['R'] = $weather_data['dailyrainmm'] ;
		@$weather_data_forward['S'] = $weather_data['irradiation'] ;
		@$weather_data_forward['TMX'] = $weather_data['temperaturec_max'] ;
		@$weather_data_forward['TMN'] = $weather_data['temperaturec_min'] ;
		@$weather_data_forward['UV'] = $weather_data['uv'] ;
		
		#@$weather_data['forward_url'] = "http://" . $forward_server . $_SERVER[REQUEST_URI];
		@$weather_data_forward['forward_url'] = "http://" . $forward_server ;
		@$weather_data_forward['forward'] = file_get_contents($weather_data_forward['forward_url'] . "?" . "U=" . @$weather_data_forward['U'] . "&PASS=" . @$weather_data_forward['PASS'] . "&T=" . @$weather_data_forward['T'] . "&H=" . @$weather_data_forward['H'] ."&P=" . @$weather_data_forward['P'] . "&R=" . @$weather_data_forward['R'] . "&UV=" . @$weather_data_forward['UV'] . "&S=" . @$weather_data_forward['S'] . "&TMX=" . @$weather_data_forward['TMX'] . "&TMN=" . @$weather_data_forward['TMN'] );
	}
	
	# Pack data into json format
	$weather_data_json = json_encode($weather_data);

	# Write json stream to logfile
	$json_data_logfile = $json_data_logdir . "/meteohelix.json";
	if ( $json_data_log == 1 ) 
	{
		$file = fopen($json_data_logfile, 'w');
		fwrite($file, $weather_data_json);
		fclose($file);
	}

	# Write stream to csvfile
	$txt_data_logfile = $txt_data_logdir . "/meteohelix_" . $date_txt . ".csv";
	if ($txt_data_log)
	{
		if (!file_exists($txt_data_logfile)) {
			$data = json_decode($weather_data_json);
			foreach($data as $key => $value) {
				$string .= $key . ',';
				}
			$string .= "\n";
			file_put_contents($txt_data_logfile, $string, FILE_APPEND);
		}
		

		$file = fopen($txt_data_logfile, 'a');
		fputcsv($file, $weather_data);
		fclose($file);
	}

	#
	# Writing accumulated rain file
	#
	$write_acc_rain = "./accumulated_rain.txt";
    $file = fopen($write_acc_rain, 'w');
	$stringa = round($weather_data['dailyrainmm'], 2) . "\n";
    fwrite($file, $stringa);
    fclose($file);
	
	#echo $h;
	#echo "\n";
	#echo $m;
	# Check if midnight =  reset file
	if( $h == 23 && $m >= 55 && $m <= 59 || $h == 0 && $m >= 0 && $m <= 5) {  
		print("Delete rain file \n");
		$write_acc_rain = "./accumulated_rain.txt";
		$file = fopen($write_acc_rain, 'w');
		$stringa = "0\n";
		fwrite($file, $stringa);
		fclose($file);
	}
	
	print("Success. Update done\n");
?>
